#include "SocketDatagrama.h"
#define PUERTO 7200

#define BUFFSIZE 20000

using namespace std;

int main(int argc, char *argv[]) {
	char buffer[BUFFSIZE];
	
	FILE *archivo;
	char msg[20];
    printf("%s\n", "SERVIDOR");
	SocketDatagrama socketCliente(PUERTO);
  	PaqueteDatagrama paq(sizeof(char));
   	

    while(1) {
        printf("ESPERANDO...\n");
    	socketCliente.recibe(&paq);
    	int aux = 0;
    
        archivo = fopen("imagen.png","rb");
        if(!archivo){
            printf("ERROR\n");
        }
        fseek(archivo, 0L, SEEK_END);
        int numero = ftell(archivo);
     	sprintf(msg, "%d", numero);

        PaqueteDatagrama cantidad(msg, BUFFSIZE, paq.obtieneDireccion(), paq.obtienePuerto());
        socketCliente.envia(&cantidad);
       
        fseek(archivo, 0L, SEEK_SET);
        while(aux <= numero/20000){
        	//printf("ENVIAMOS\n");
            aux++;
			int leidos = fread(buffer,sizeof(char),BUFFSIZE,archivo);
            if(leidos == 0){
                printf("%d\n", aux);
                exit(1);
            }
			printf("%s", buffer);
					
			PaqueteDatagrama paquete(buffer, 20000, paq.obtieneDireccion(), paq.obtienePuerto());
			socketCliente.envia(&paquete);
            sleep(0.5);
		}
		printf("SALE WHILE\n");
    }

    return 0;
}
