#include "SocketDatagrama.h"
#include <string.h>
#define PUERTO 7200


using namespace std;

int main(int argc, char *argv[]) {

    int repuesta;
    char name[20]={0};
    char *IP[4];
    char *cadena;
    char *IP2[4];
    char ultimo[3];
    char enviaip1[11];
    char ipaux[11];
    char *cadena2;
    char *tk;
    FILE *file;  

    printf("%s\n", "CLIENTE");
    printf("%s\n", "ENVIANDO PAQUETE...");
    
    cadena = argv[1];
    cadena2 = argv [2];
    int time = atoi(argv[3]);

    //PRIMERA IP
    tk = strtok(cadena,".");
    IP[0] = tk;
    int oct = atoi(tk);
   
    memcpy(enviaip1, IP[0], sizeof(IP[0]));
    int aux = 0;
    while(aux != 3){
        aux ++;
        tk = strtok(NULL,".");
        IP[aux] = tk;
        oct = atoi(tk);
            if(aux < 3){
                strcat(enviaip1, ".");
                strcat(enviaip1, IP[aux]);
            }

    }   

    //SEGUNDA IP
    tk = strtok(cadena2,".");
    IP2[0] = tk;
    int oct2 = atoi(tk);
    aux = 0;
    while(aux != 3){
        aux ++;
        tk = strtok(NULL,".");
        IP2[aux] = tk;
        oct2 = atoi(tk);
    }   
  

    
    strcat(enviaip1, ".");
    
    SocketDatagrama socketCliente(PUERTO);
    while(1){
        printf("Pasaron 10 segundos\n");
    for(int x = oct; x <= oct2; x++){
    memcpy(ipaux, enviaip1, sizeof(enviaip1));
    sprintf(ultimo, "%d", x);
    strcat(ipaux, ultimo);

    PaqueteDatagrama paquete("si", 8, ipaux, PUERTO);
    printf("Mandando paquete a: %s:%d\n", paquete.obtieneDireccion(), paquete.obtienePuerto());
    socketCliente.envia(&paquete);
    printf("%s\n", "PAQUETE ENVIADO");
    sprintf(name, "imagen%02d.png", x); 
    file = fopen(name,"wb");

    PaqueteDatagrama cantidad(sizeof(long int));
    socketCliente.recibe(&cantidad);

    int num = atoi(cantidad.obtieneDatos());
    int aux2 = num;
    printf("NUMERO DE BYTES: %d\n", num);


    PaqueteDatagrama entrada(20000);
    int recibido = 0;
    while(recibido <= num/20000){
        recibido++;
        aux2--;
        socketCliente.recibe(&entrada);
        //buffer = entrada.obtieneDatos();
        //printf("%s", entrada.obtieneDatos());
        fwrite(entrada.obtieneDatos(),sizeof(char),20000,file);


       }
       fclose(file);

    //sleep(5);
     printf("Recibimos %d\n", x);
      //sleep(0.5);
}
sleep(time);
}
   

    return 0;
}
