#include <time.h>
#include<stdio.h>
 
int main (void)
{
    clock_t start, diff;
    int elapsedsec;
    int sec = 10;
    int iterations = 0;
 
    while (1) {
        start = clock();
 
        while (1) {
            diff = clock() - start;
            elapsedsec = diff / CLOCKS_PER_SEC;
 
            if (elapsedsec >= sec) {
                printf("Pasaron 10 segundo\n");
 
                //iterations++;
                break;
            }
        }
    }
    
    return 0;
}