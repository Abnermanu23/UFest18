#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <cstring>
#include <sstream>

using namespace std;

int main(int argc, char *argv[]){
    char *IP[4];
    char *cadena;
    char *IP2[4];
    char enviaip1[11];
    char ipaux[11];
    char ultimo[2];
    char *cadena2;
    char *tk;
    
    cadena = argv[1];
    cadena2 = argv [2];

    cout << "METIDA: " << cadena << endl;
    //PRIMERA IP
    tk = strtok(cadena,".");
    IP[0] = tk;
    int oct = atoi(tk);
   // cout << "CADENA" << IP[0] << "   ENTERO" << oct << endl;
    memcpy(enviaip1, IP[0], sizeof(IP[0]));
    int aux = 0;
    while(aux != 3){
    aux ++;
    tk = strtok(NULL,".");
    IP[aux] = tk;
    oct = atoi(tk);
    if(aux < 3){
    strcat(enviaip1, ".");
    strcat(enviaip1, IP[aux]);
    //cout << "CADENA EN IF   " << enviaip1 << endl;
    }

    }   

    //SEGUNDA IP
    tk = strtok(cadena2,".");
    IP2[0] = tk;
    int oct2 = atoi(tk);
    //cout << "CADENA2" << IP2[0] << "   ENTERO2" << oct2 << endl;
    aux = 0;
    while(aux != 3){
    aux ++;
    tk = strtok(NULL,".");
    IP2[aux] = tk;
    oct2 = atoi(tk);
    //cout << "CADENA" << IP2[aux] << "   ENTERO" << oct2 << endl;

    }   
  

    
    strcat(enviaip1, ".");

    cout << "IP ENVIA:: " << enviaip1 << endl;

    for(int x = oct; x <= oct2; x++){
    memcpy(ipaux, enviaip1, sizeof(enviaip1));
    //cout << "AUX IP------------   " << ipaux << endl;
    sprintf(ultimo, "%d", x);
    strcat(ipaux, ultimo);
    cout << "AUX IP::::::::::" << ipaux << endl;   
    }


}